

# bot.py

import logging
import os
import asyncio
from uuid import uuid4
from datetime import datetime, timedelta

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup, BotCommand
from telegram.ext import (
    Application, CommandHandler, MessageHandler,
    CallbackQueryHandler, ChatMemberHandler,
    ContextTypes, filters
)

# Django setup
os.environ.setdefault("DJANGO_SETTINGS_MODULE", "payments.settings")
import django
django.setup()

from asgiref.sync import sync_to_async
from bot_tel.models import User, Payment, Invitation, AccessLog

# --- تنظیمات ---
# تنظیمات ربات
TOKEN = "6191203365:AAF3pohjgvXATSe1LTFow9aAmM-4fR7L7sM"
ADMIN_IDS = [6217959067]
GROUP_ID = -1002583432591
ACCESS_DURATION = 1  # دقیقه
PAYMENT_ACCOUNT = "1234-5678-9012-3456"
COMMISSION_RATES = {1: 0.08, 2: 0.12}
PRICE = 100000  # به ریال

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# --- توابع پایگاه‌داده ---
logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)
logger = logging.getLogger(__name__)

# توابع دیتابیس
# توابع دیتابیس
@sync_to_async
def get_user(user_id):
    return User.objects.filter(user_id=user_id).first()

@sync_to_async
def update_user(user_id, **kwargs):
    return User.objects.filter(user_id=user_id).update(**kwargs)

@sync_to_async
def register_user(user_id, username, first_name, last_name, invited_by=None):
    return User.objects.create(user_id=user_id, username=username, first_name=first_name, last_name=last_name, invited_by=invited_by)

@sync_to_async
def register_invitation(inviter_id, invited_id, level):
    try:
        Invitation.objects.create(inviter_id=inviter_id, invited_id=invited_id, level=level)
    except:
        pass

@sync_to_async
def create_payment_request(user_id, amount, screenshot_path=None):
    payment = Payment.objects.create(user_id=user_id, amount=amount, screenshot_path=screenshot_path, unique_id=str(uuid4()))
    return payment.id

@sync_to_async
def approve_payment_by_id(payment_id, admin_id):
    payment = Payment.objects.filter(id=payment_id).first()
    if not payment:
        return None
    payment.status = "approved"
    payment.admin_id = admin_id
    payment.save()
    return payment.user_id

@sync_to_async
def reject_payment_by_id(payment_id, admin_id):
    payment = Payment.objects.filter(id=payment_id).first()
    if not payment:
        return None
    payment.status = "rejected"
    payment.admin_id = admin_id
    payment.save()
    return payment.user_id

@sync_to_async
def log_access_entry(user_id, payment_id):
    AccessLog.objects.create(user_id=user_id, join_time=datetime.now(), payment_id=payment_id)

@sync_to_async
def log_access_exit(user_id):
    last_log = AccessLog.objects.filter(user_id=user_id, leave_time__isnull=True).order_by('-join_time').first()
    if last_log:
        last_log.leave_time = datetime.now()
        last_log.save()

@sync_to_async
def apply_commissions(user_id, amount):
    user = User.objects.filter(user_id=user_id).first()
    if user and user.invited_by:
        inviter1 = User.objects.filter(user_id=user.invited_by).first()
        if inviter1:
            inviter1.balance += amount * COMMISSION_RATES[1]
            inviter1.save()
        if inviter1 and inviter1.invited_by:
            inviter2 = User.objects.filter(user_id=inviter1.invited_by).first()
            if inviter2:
                inviter2.balance += amount * COMMISSION_RATES[2]
                inviter2.save()

# دستورات اصلی ربات
async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    existing_user = await get_user(user.id)

    if not existing_user:
        ref = None
        if context.args and context.args[0].startswith("ref="):
            try:
                ref = int(context.args[0][4:])
            except ValueError:
                ref = None
        await register_user(user.id, user.username, user.first_name, user.last_name, invited_by=ref)
        if ref:
            await register_invitation(ref, user.id, 1)
            inviter = await get_user(ref)
            if inviter and inviter.invited_by:
                await register_invitation(inviter.invited_by, user.id, 2)

    await show_main_menu(update, user.id)

async def show_main_menu(update: Update, user_id):
    user = await get_user(user_id)
    status = "✅ فعال" if user and user.is_active else "❌ غیرفعال"
    keyboard = [
        [InlineKeyboardButton("💳 خرید دسترسی", callback_data="buy_access")],
        [InlineKeyboardButton("👥 دعوت از دوستان", callback_data="invite_friends")],
        [InlineKeyboardButton("💰 کیف پول", callback_data="wallet")]
    ]
    if user_id in ADMIN_IDS:
        keyboard.append([InlineKeyboardButton("🔧 پنل مدیریت", callback_data="admin_panel")])
    reply_markup = InlineKeyboardMarkup(keyboard)
    text = f"""🔸 وضعیت حساب: {status}
👤 کد کاربری: {user_id}
"""
    if update.message:
        await update.message.reply_text(text, reply_markup=reply_markup)
    else:
        await update.callback_query.edit_message_text(text, reply_markup=reply_markup)

async def buy_access(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    text = f"""💳 خرید دسترسی

💰 مبلغ قابل پرداخت: {PRICE:,} تومان
🔄 مدت دسترسی: {ACCESS_DURATION} دقیقه

برای خرید:
1. مبلغ را به شماره کارت زیر واریز کنید:
{PAYMENT_ACCOUNT}

2. تصویر رسید پرداخت را ارسال کنید.
"""
    keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def buy_access(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    text = f"""💳 خرید دسترسی

💰 مبلغ قابل پرداخت: {PRICE:,} تومان
🔄 مدت دسترسی: {ACCESS_DURATION} دقیقه

برای خرید:
1. مبلغ را به شماره کارت زیر واریز کنید:
{PAYMENT_ACCOUNT}

2. تصویر رسید پرداخت را ارسال کنید.
    """
    keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

async def handle_payment_screenshot(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    user_data = await get_user(user.id)
    if not user_data:
        await update.message.reply_text("⚠️ خطا در شناسایی کاربر.")
        return
    photo_file = await update.message.photo[-1].get_file()
    screenshot_path = f"media/payments/{user.id}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.jpg"
    os.makedirs(os.path.dirname(screenshot_path), exist_ok=True)
    await photo_file.download_to_drive(screenshot_path)
    payment_id = await create_payment_request(user.id, PRICE, screenshot_path)
    for admin_id in ADMIN_IDS:
        await context.bot.send_photo(
            chat_id=admin_id,
            photo=screenshot_path,
            caption=f"📥 پرداخت جدید:\n🆔 کد: {payment_id}\n👤 @{user.username or 'بدون نام'} (ID: {user.id})\n💵 مبلغ: {PRICE:,} تومان\n\n✅ /approve {payment_id}\n❌ /reject {payment_id}"
        )
    await update.message.reply_text("✅ رسید شما دریافت شد. منتظر تایید ادمین باشید.")

async def approve(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ دسترسی ندارید.")
        return
    if not context.args:
        await update.message.reply_text("مثال: /approve 12")
        return
    try:
        payment_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("کد پرداخت معتبر نیست.")
        return

    approved_user_id = await approve_payment_by_id(payment_id, user.id)
    if not approved_user_id:
        await update.message.reply_text("پرداخت پیدا نشد.")
        return

    await log_access_entry(approved_user_id, payment_id)
    await apply_commissions(approved_user_id, PRICE)

    try:
        invite_link = await context.bot.create_chat_invite_link(
            chat_id=GROUP_ID,
            name=f"Access-{approved_user_id}",
            member_limit=1,
            expire_date=int((datetime.now() + timedelta(hours=1)).timestamp())
        )
        await context.bot.send_message(
            chat_id=approved_user_id,
            text=f"✅ پرداخت تایید شد!\n\n🔗 لینک عضویت:\n{invite_link.invite_link}\n\n⏳ مدت دسترسی: {ACCESS_DURATION} دقیقه"
        )
        context.job_queue.run_once(
            callback=remove_user_callback,
            when=ACCESS_DURATION * 60,
            data={"user_id": approved_user_id},
            name=f"remove-{approved_user_id}"
        )
        await update.message.reply_text("✅ تایید شد و لینک ارسال گردید.")
    except Exception as e:
        logger.error(f"❌ خطا در ساخت لینک دعوت: {e}")
        await update.message.reply_text("⚠️ خطا در ساخت لینک. مطمئن شوید ربات ادمین گروه است.")

async def reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    if user.id not in ADMIN_IDS:
        await update.message.reply_text("⛔ دسترسی ندارید.")
        return
    if not context.args:
        await update.message.reply_text("مثال: /reject 12")
        return
    try:
        payment_id = int(context.args[0])
    except ValueError:
        await update.message.reply_text("کد پرداخت معتبر نیست.")
        return

    rejected_user_id = await reject_payment_by_id(payment_id, user.id)
    if not rejected_user_id:
        await update.message.reply_text("پرداخت پیدا نشد.")
        return

    await context.bot.send_message(
        chat_id=rejected_user_id,
        text="❌ پرداخت شما تایید نشد. لطفاً دوباره تلاش کنید."
    )
    await update.message.reply_text("❌ پرداخت رد شد.")


async def remove_user_callback(context: ContextTypes.DEFAULT_TYPE):
    user_id = context.job.data["user_id"]
    try:
        # مسدود و سپس رفع مسدودی برای حذف (روش رسمی تلگرام برای حذف کاربر توسط ربات)
        await context.bot.ban_chat_member(chat_id=GROUP_ID, user_id=user_id,
                                          until_date=int((datetime.now() + timedelta(minutes=1)).timestamp()))
        await context.bot.unban_chat_member(chat_id=GROUP_ID, user_id=user_id)

        # غیرفعال‌سازی در دیتابیس
        await update_user(user_id, is_active=False)
        await log_access_exit(user_id)

        # اطلاع‌رسانی به کاربر
        await context.bot.send_message(
            chat_id=user_id,
            text="⏳ مدت دسترسی شما به پایان رسید. برای تمدید اشتراک، دوباره پرداخت انجام دهید."
        )
    except Exception as e:
        logger.error(f"❌ خطا در حذف کاربر {user_id}: {e}")

    # مدیریت دکمه‌ها


async def button_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    data = query.data

    if data == "buy_access":
        await buy_access(update, context)
    elif data == "invite_friends":
        await invite_friends(update, context)
    elif data == "wallet":
        await wallet(update, context)
    elif data == "admin_panel":
        await admin_panel(update, context)
    elif data == "main_menu":
        await show_main_menu(update, query.from_user.id)
    else:
        await query.edit_message_text("دکمه نامعتبر!")

    # دعوت دوستان


async def invite_friends(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user_id = query.from_user.id
    invite_link = f"https://t.me/{(await context.bot.get_me()).username}?start=ref={user_id}"
    text = f"""👥 دعوت از دوستان

 🔗 لینک دعوت اختصاصی شما:
 {invite_link}

 💰 پورسانت:
 • سطح ۱: {COMMISSION_RATES[1] * 100}٪
 • سطح ۲: {COMMISSION_RATES[2] * 100}٪
 """
    keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

    # کیف پول


async def wallet(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    user = await get_user(query.from_user.id)
    text = f"💰 کیف پول شما\n\n💵 موجودی: {user.balance:,.0f} تومان"
    keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

    # پنل مدیریت


async def admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        await query.edit_message_text("⛔ شما دسترسی ندارید.")
        return
    text = "🔧 پنل مدیریت:"
    keyboard = [
        [InlineKeyboardButton("📥 پرداخت‌های در انتظار", callback_data="pending_payments")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]
    ]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))

    # نمایش پرداخت‌های در انتظار


@sync_to_async
def get_pending_payments():
    return list(Payment.objects.filter(status="pending").order_by("-date"))


async def pending_payments(update: Update, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()
    if query.from_user.id not in ADMIN_IDS:
        await query.edit_message_text("⛔ شما دسترسی ندارید.")
        return
    payments = await get_pending_payments()
    if not payments:
        await query.edit_message_text("📭 پرداخت در انتظاری یافت نشد.")
        return
    text = "📋 پرداخت‌های در انتظار:\n\n"
    for p in payments:
        text += f"🆔 {p.id} | 👤 {p.user_id} | 💵 {p.amount:,.0f} تومان\n"
    keyboard = [[InlineKeyboardButton("🔙 بازگشت", callback_data="main_menu")]]
    await query.edit_message_text(text, reply_markup=InlineKeyboardMarkup(keyboard))


# راه‌اندازی دستورات ربات
async def setup_commands(app: Application):
    await app.bot.set_my_commands([
        BotCommand("start", "شروع"),
        BotCommand("approve", "تایید پرداخت"),
        BotCommand("reject", "رد پرداخت")
    ])


# اجرای اصلی ربات
def main():
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    app = Application.builder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(CommandHandler("approve", approve))
    app.add_handler(CommandHandler("reject", reject))
    app.add_handler(MessageHandler(filters.PHOTO, handle_payment_screenshot))
    app.add_handler(CallbackQueryHandler(button_handler))

    loop.run_until_complete(setup_commands(app))
    loop.run_until_complete(app.run_polling())