# run.py
import os
import django

os.environ.setdefault("DJANGO_SETTINGS_MODULE", "payments.settings")
django.setup()

import bot  # اطمینان حاصل کن که فایل bot.py در کنار این فایل قرار داره

if __name__ == "__main__":
    bot.main()