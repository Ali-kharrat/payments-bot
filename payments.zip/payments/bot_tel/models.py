# bot/models.py
from django.db import models

class User(models.Model):
    user_id = models.BigIntegerField(primary_key=True)
    username = models.CharField(max_length=255, null=True, blank=True)
    first_name = models.CharField(max_length=255, null=True, blank=True)
    last_name = models.CharField(max_length=255, null=True, blank=True)
    join_date = models.DateTimeField(auto_now_add=True)
    invited_by = models.BigIntegerField(null=True, blank=True)
    balance = models.FloatField(default=0)
    last_payment_date = models.DateTimeField(null=True, blank=True)
    is_active = models.BooleanField(default=False)
    payment_count = models.PositiveIntegerField(default=0)

    def __str__(self):
        return f"{self.user_id} - {self.username}"

class Invitation(models.Model):
    inviter_id = models.BigIntegerField()
    invited_id = models.BigIntegerField()
    level = models.IntegerField()
    date = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ("inviter_id", "invited_id")

    def __str__(self):
        return f"{self.inviter_id} → {self.invited_id} (سطح {self.level})"

class Payment(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    amount = models.FloatField()
    screenshot_path = models.CharField(max_length=255, null=True, blank=True)
    status = models.CharField(max_length=32, choices=[("pending", "در انتظار"), ("approved", "تایید شده")], default="pending")
    admin_id = models.BigIntegerField(null=True, blank=True)
    date = models.DateTimeField(auto_now_add=True)
    unique_id = models.CharField(max_length=100, unique=True)

    def __str__(self):
        return f"پرداخت {self.id} - {self.user_id} ({self.status})"


class AccessLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    join_time = models.DateTimeField()
    leave_time = models.DateTimeField(null=True, blank=True)
    payment = models.ForeignKey(Payment, on_delete=models.SET_NULL, null=True)

    def __str__(self):
        return f"{self.user.username} | {self.join_time.strftime('%Y-%m-%d %H:%M')}"