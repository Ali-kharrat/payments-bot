from django.contrib import admin

# Register your models here.
# bot/admin.py
from django.contrib import admin
from .models import User, Invitation, Payment

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ("user_id", "username", "first_name", "is_active", "balance", "payment_count")
    search_fields = ("user_id", "username", "first_name", "last_name")
    list_filter = ("is_active",)

@admin.register(Invitation)
class InvitationAdmin(admin.ModelAdmin):
    list_display = ("inviter_id", "invited_id", "level", "date")
    search_fields = ("inviter_id", "invited_id")
    list_filter = ("level",)

@admin.register(Payment)
class PaymentAdmin(admin.ModelAdmin):
    list_display = ("id", "user", "amount", "status", "admin_id", "date")
    search_fields = ("user__username", "user__user_id", "unique_id")
    list_filter = ("status", "date")