from django.apps import AppConfig


class BotTelConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'bot_tel'
